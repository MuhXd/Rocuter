--Start.; txt+lua ;.End--

print("Test Lua")